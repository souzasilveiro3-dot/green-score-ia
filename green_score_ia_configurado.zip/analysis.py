"""
Green Score IA - Motor de probabilidades (analysis.py)
========================================================

Calcula probabilidades de resultado, gols, ambas marcam (BTTS) e escanteios
a partir de médias REAIS de cada time (que o app.py busca na API-Football).

Este módulo não inventa números: ele só faz contas em cima do que recebe.
Se os dados de entrada vierem incompletos, o app.py que decide o que fazer
(hoje: avisa o usuário em vez de estimar um número no lugar).

Método: distribuição de Poisson sobre o número de gols esperado de cada
time — o modelo estatístico mais comum (e mais simples) em análise de
futebol. É uma aproximação matemática, não uma garantia de resultado.
"""

from __future__ import annotations

from dataclasses import dataclass
from math import exp, factorial, floor
from typing import Dict


def _poisson(k: int, lam: float) -> float:
    """P(X = k) para uma variável de Poisson com média lam."""
    if lam <= 0:
        return 1.0 if k == 0 else 0.0
    return (lam ** k) * exp(-lam) / factorial(k)


def _matriz_placares(lambda_casa: float, lambda_fora: float, max_gols: int = 8):
    """Matriz [gols_casa][gols_fora] -> probabilidade daquele placar exato."""
    return [
        [_poisson(i, lambda_casa) * _poisson(j, lambda_fora) for j in range(max_gols + 1)]
        for i in range(max_gols + 1)
    ]


def _probabilidades_1x2(matriz) -> Dict[str, float]:
    vitoria_casa = empate = vitoria_fora = 0.0
    for i, linha in enumerate(matriz):
        for j, p in enumerate(linha):
            if i > j:
                vitoria_casa += p
            elif i == j:
                empate += p
            else:
                vitoria_fora += p
    return {"vitoria_casa": vitoria_casa, "empate": empate, "vitoria_fora": vitoria_fora}


def _probabilidade_over(matriz, linha: float) -> float:
    total = 0.0
    for i, linha_gols in enumerate(matriz):
        for j, p in enumerate(linha_gols):
            if (i + j) > linha:
                total += p
    return total


def _probabilidade_btts(matriz) -> float:
    total = 0.0
    for i, linha_gols in enumerate(matriz):
        for j, p in enumerate(linha_gols):
            if i > 0 and j > 0:
                total += p
    return total


def _probabilidade_escanteios_over(media_casa: float, media_fora: float, linha: float = 9.5) -> float:
    """Aproxima o total de escanteios do jogo por uma Poisson com média = soma das médias dos times."""
    lam = max(media_casa + media_fora, 0.0)
    limite_inteiro = floor(linha)
    prob_ate_o_limite = sum(_poisson(k, lam) for k in range(0, limite_inteiro + 1))
    return max(0.0, 1 - prob_ate_o_limite)


@dataclass
class ResultadoAnalise:
    gols_esperados_casa: float
    gols_esperados_fora: float
    resultado: Dict[str, float]
    gols_over_1_5: float
    gols_over_2_5: float
    gols_under_2_5: float
    ambas_marcam: float
    escanteios_esperados: float
    escanteios_over_9_5: float

    def to_dict(self) -> dict:
        return {
            "gols_esperados": {
                "mandante": round(self.gols_esperados_casa, 2),
                "visitante": round(self.gols_esperados_fora, 2),
            },
            "resultado": {k: round(v, 4) for k, v in self.resultado.items()},
            "gols": {
                "mais_de_1_5": round(self.gols_over_1_5, 4),
                "mais_de_2_5": round(self.gols_over_2_5, 4),
                "menos_de_2_5": round(self.gols_under_2_5, 4),
            },
            "ambas_marcam": round(self.ambas_marcam, 4),
            "escanteios": {
                "media_esperada": round(self.escanteios_esperados, 2),
                "mais_de_9_5": round(self.escanteios_over_9_5, 4),
            },
        }


def analisar_partida(
    gols_marcados_casa: float,
    gols_sofridos_casa: float,
    gols_marcados_fora: float,
    gols_sofridos_fora: float,
    escanteios_casa: float = 0.0,
    escanteios_fora: float = 0.0,
) -> dict:
    """
    Recebe médias reais (gols e escanteios) dos dois times e devolve probabilidades
    de resultado, gols, BTTS e escanteios.

    Simplificação assumida: o número esperado de gols de cada time é a média entre
    o que ele costuma marcar (em casa/fora) e o que o adversário costuma sofrer
    (fora/em casa) — o mesmo princípio do modelo de Poisson usado em análise de
    apostas, só que ainda sem normalizar pela média geral de gols da liga. Isso
    entra como refinamento futuro, quando tivermos esse número por competição.
    """
    lambda_casa = (gols_marcados_casa + gols_sofridos_fora) / 2
    lambda_fora = (gols_marcados_fora + gols_sofridos_casa) / 2

    matriz = _matriz_placares(lambda_casa, lambda_fora)

    resultado = _probabilidades_1x2(matriz)
    over_1_5 = _probabilidade_over(matriz, 1.5)
    over_2_5 = _probabilidade_over(matriz, 2.5)
    under_2_5 = 1 - over_2_5
    btts = _probabilidade_btts(matriz)
    escanteios_esperados = escanteios_casa + escanteios_fora
    escanteios_over = _probabilidade_escanteios_over(escanteios_casa, escanteios_fora)

    analise = ResultadoAnalise(
        gols_esperados_casa=lambda_casa,
        gols_esperados_fora=lambda_fora,
        resultado=resultado,
        gols_over_1_5=over_1_5,
        gols_over_2_5=over_2_5,
        gols_under_2_5=under_2_5,
        ambas_marcam=btts,
        escanteios_esperados=escanteios_esperados,
        escanteios_over_9_5=escanteios_over,
    )
    return analise.to_dict()


if __name__ == "__main__":
    # Exemplo manual (números fictícios) só para conferir o cálculo isoladamente,
    # sem precisar subir o servidor nem chamar a API-Football.
    import json

    exemplo = analisar_partida(
        gols_marcados_casa=1.8,
        gols_sofridos_casa=1.1,
        gols_marcados_fora=1.3,
        gols_sofridos_fora=1.4,
        escanteios_casa=5.4,
        escanteios_fora=4.1,
    )
    print(json.dumps(exemplo, indent=2, ensure_ascii=False))
