# Green Score IA — Backend

Backend em FastAPI que busca jogos, estatísticas, eventos e previsões na
API-Football e serve o aplicativo Green Score IA.

Fluxo: **API-Football → este servidor (app.py) → aplicativo/site**

## 1. Pré-requisitos

- Python 3.10+
- Uma chave de API válida em https://www.api-football.com (ou o mesmo serviço
  via RapidAPI)

## 2. Instalação

```bash
cd backend
python -m venv .venv
source .venv/bin/activate        # Windows: .venv\Scripts\activate
pip install -r requirements.txt
```

## 3. Configurar a chave da API

Abra o arquivo `.env` e troque `coloque_sua_chave_aqui` pela sua chave real:

```
API_FOOTBALL_KEY=sua_chave_real_aqui
```

A chave nunca fica escrita no código-fonte (`app.py`) — ela é lida do
ambiente em tempo de execução, via `python-dotenv`. Não suba o `.env` para
um repositório público (ele já está no `.gitignore`).

## 4. Rodar o servidor

```bash
uvicorn app:app --reload
```

O servidor sobe em `http://127.0.0.1:8000`. Abrindo esse endereço no navegador
você já vê o próprio site (Green Score IA) rodando localmente, com dados reais.
A documentação interativa da API (para testar cada rota clicando) fica em
`http://127.0.0.1:8000/docs`.

## 5. Rotas disponíveis

| Rota                              | O que faz                                              |
|-----------------------------------|---------------------------------------------------------|
| `GET /jogos/hoje`                 | Jogos do dia (filtros opcionais `liga`, `temporada`)    |
| `GET /jogos/ao-vivo`              | Jogos acontecendo agora (filtro opcional `liga`)        |
| `GET /jogo/{id}/estatisticas`     | Posse de bola, finalizações, escanteios, cartões, etc.  |
| `GET /jogo/{id}/eventos`          | Linha do tempo: gols, cartões, substituições, VAR       |
| `GET /jogo/{id}/previsao`         | Previsão (por enquanto, repassada da própria API-Football) |

O `{id}` é o `fixture_id` da API-Football (aparece na resposta de
`/jogos/hoje` e `/jogos/ao-vivo`, campo `fixture.id`).

Exemplo:

```bash
curl "http://127.0.0.1:8000/jogos/hoje"
curl "http://127.0.0.1:8000/jogo/1035037/estatisticas"
```

## 7. Camada de IA (explicação em texto)

O arquivo `ai_explainer.py` usa a API da Anthropic para **explicar em texto**
os números que o `analysis.py` já calculou — ele não recebe nem inventa
nenhum dado além do que já veio da API-Football + analysis.py.

1. Crie uma chave em https://console.anthropic.com
2. Cole no `.env`:
   ```
   ANTHROPIC_API_KEY=sua_chave_real_aqui
   ```
3. Pronto — a rota `/jogo/{id}/previsao` passa a incluir o campo
   `explicacao_ia` com um textinho explicando o confronto.

Isso é **opcional**: sem a chave, a rota continua funcionando normalmente,
só que `explicacao_ia` vem como `null`. Cada chamada consome créditos da
sua conta Anthropic (é uma API paga, com preço por token).

## 6. Publicar o site (front-end + API juntos, com uma URL só)

O `app.py` agora também serve o site: a pasta `static/index.html` é o mesmo
Green Score IA que você viu no Claude, e o backend serve ela na raiz (`/`),
enquanto as rotas de API continuam em `/jogos/...`, `/jogo/{id}/...`. Como
tudo fica na mesma origem, o site chama a API sem precisar configurar nada.

**Passo a passo pelo Render (grátis, mais simples):**

1. Crie uma conta em https://render.com (pode entrar com GitHub).
2. Suba esta pasta `backend/` para um repositório no GitHub (o `.env` fica de
   fora automaticamente, por causa do `.gitignore`).
3. No Render, clique em **New +** → **Blueprint**, aponte para o seu
   repositório — ele lê o `render.yaml` sozinho e já configura tudo.
   (Se preferir sem Blueprint: **New +** → **Web Service** → escolha o
   repositório → Environment: **Docker**.)
4. Quando pedir a variável `API_FOOTBALL_KEY`, cole sua chave real ali no
   painel (nunca no código).
5. Clique em **Deploy**. Em alguns minutos o Render te dá uma URL pública,
   tipo `https://green-score-ia.onrender.com` — abra ela: é o site
   completo, com os dados reais de `/jogos/hoje` e `/jogos/ao-vivo`.

**Alternativas** (mesmo Dockerfile funciona): Railway, Fly.io, ou uma VPS
com Docker instalado (`docker build -t green-score-ia . && docker run -p 8000:8000 --env-file .env green-score-ia`).

> Plano free do Render "dorme" depois de um tempo sem acesso e demora uns
> segundos para acordar na próxima visita — normal, não é bug.

## 8. O que ainda falta para o produto ficar 100% pronto

- ~~Camada de IA que explica os números~~ ✅ feito (`ai_explainer.py`).
- ~~Análise da IA aparecendo no site~~ ✅ feito — aba Palpites IA, painel
  "Análise da IA — jogos de hoje", quando o backend está conectado.
- **Ligar o gerador de múltiplas ("Escolha a odd que você quer") na previsão
  real** — ele ainda usa um pool de mercados de demonstração; o próximo
  passo é ele montar as pernas a partir de `/jogo/{id}/previsao` (convertendo
  probabilidade em odd justa estimada) em vez dos valores fixos de agora.
- **Escanteios**: a média vem calculada em cima dos últimos 5 jogos de cada
  time — dá pra ajustar esse número ou usar um endpoint dedicado se seu
  plano da API-Football tiver um mais direto.
- **Brasileirão e outras ligas**: confirme os ids de liga certos no plano da
  sua chave da API-Football (parâmetro `liga` nas rotas).
- **Publicar de verdade** (seção 6 acima) — ainda não foi feito.
