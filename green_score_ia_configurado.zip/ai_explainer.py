"""
Green Score IA - Camada de IA (ai_explainer.py)
=================================================

Usa a API da Anthropic para transformar os números que o analysis.py já
calculou em uma explicação em texto, em português, para quem está no site.

Regra de ouro: a IA só pode comentar os números que chegam até ela. Ela não
busca dado novo, não inventa estatística, escalação ou notícia, e não
recomenda apostas — só interpreta o que o motor matemático já produziu.

Se ANTHROPIC_API_KEY não estiver configurada, ou a chamada falhar por
qualquer motivo, a função devolve None e o app.py simplesmente não inclui
a explicação na resposta — os números do analysis.py continuam disponíveis
normalmente, sem depender da IA para funcionar.
"""

import json
import os
from typing import Optional

from anthropic import Anthropic, APIError

ANTHROPIC_API_KEY = os.environ.get("ANTHROPIC_API_KEY")
ANTHROPIC_MODEL = os.environ.get("ANTHROPIC_MODEL", "claude-sonnet-5")

_cliente: Optional[Anthropic] = None


def _obter_cliente() -> Optional[Anthropic]:
    """Cria o cliente da Anthropic uma única vez (se houver chave configurada)."""
    global _cliente
    if not ANTHROPIC_API_KEY:
        return None
    if _cliente is None:
        _cliente = Anthropic(api_key=ANTHROPIC_API_KEY)
    return _cliente


SYSTEM_PROMPT = """Você é um analista esportivo do site Green Score IA.
Sua única função é EXPLICAR, em português do Brasil, números de probabilidade
que já foram calculados matematicamente e que serão fornecidos a você em JSON.

Regras obrigatórias:
- Use SOMENTE os números fornecidos. Não invente estatísticas, escalações,
  lesões, notícias, arbitragem ou qualquer outro dado que não esteja no JSON.
- Não garanta resultado nenhum: fale sempre em termos de probabilidade
  ("é mais provável", "o modelo aponta", "as chances calculadas indicam").
- Não recomende se a pessoa deve ou não apostar, nem sugira valores de aposta.
- Seja objetivo: no máximo 4 frases corridas, sem tópicos, sem markdown.
- Não liste os números um a um; interprete o conjunto (ex.: se o jogo tende
  a ter poucos ou muitos gols, se é um confronto equilibrado ou com favorito
  claro, se o time costuma ganhar escanteios ou não)."""


def explicar_previsao(mandante: str, visitante: str, previsao: dict) -> Optional[str]:
    """
    Pede ao modelo da Anthropic para explicar, em texto, as probabilidades já
    calculadas pelo analysis.py.

    Devolve None se a IA não estiver configurada (sem ANTHROPIC_API_KEY) ou se
    a chamada falhar — nesses casos o app.py só omite o campo de explicação e
    mantém os números do analysis.py normalmente.
    """
    cliente = _obter_cliente()
    if cliente is None:
        return None

    conteudo_usuario = (
        f"Partida: {mandante} (mandante) x {visitante} (visitante)\n\n"
        f"Números calculados (JSON):\n{json.dumps(previsao, ensure_ascii=False)}"
    )

    try:
        resposta = cliente.messages.create(
            model=ANTHROPIC_MODEL,
            max_tokens=300,
            system=SYSTEM_PROMPT,
            messages=[{"role": "user", "content": conteudo_usuario}],
        )
    except APIError:
        return None
    except Exception:
        return None

    partes_texto = [
        bloco.text for bloco in resposta.content if getattr(bloco, "type", None) == "text"
    ]
    texto = "\n".join(partes_texto).strip()
    return texto or None
