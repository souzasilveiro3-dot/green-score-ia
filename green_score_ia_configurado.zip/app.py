"""
Green Score IA - Backend
=========================

Camada entre a API-Football e o aplicativo Green Score IA.

Fluxo: API-Football  →  este servidor (app.py)  →  aplicativo/site

Por enquanto este arquivo só busca e repassa dados reais da API-Football.
O motor de probabilidades (analysis.py) e a camada de IA que explica os
números entram nos próximos passos, sem inventar dados por conta própria.

IMPORTANTE: a chave da API-Football NUNCA fica escrita neste arquivo.
Ela é lida da variável de ambiente API_FOOTBALL_KEY (veja o arquivo .env).
"""

import os
from datetime import date
from statistics import mean
from typing import Optional

import httpx
from dotenv import load_dotenv
from fastapi import FastAPI, HTTPException
from fastapi.middleware.cors import CORSMiddleware
from fastapi.staticfiles import StaticFiles

from analysis import analisar_partida
from ai_explainer import explicar_previsao

# Carrega as variáveis do arquivo .env para o ambiente do processo
load_dotenv()

API_FOOTBALL_KEY = os.environ.get("API_FOOTBALL_KEY")
API_FOOTBALL_BASE_URL = os.environ.get(
    "API_FOOTBALL_BASE_URL", "https://v3.football.api-sports.io"
)

app = FastAPI(
    title="Green Score IA - API",
    description="Backend que busca jogos, estatísticas, eventos e previsões na API-Football.",
    version="0.1.0",
)

# CORS liberado para o app conseguir chamar essa API a partir do navegador.
# Em produção, troque "*" pela URL real do seu site.
app.add_middleware(
    CORSMiddleware,
    allow_origins=["*"],
    allow_methods=["*"],
    allow_headers=["*"],
)


def get_headers() -> dict:
    """Monta o cabeçalho de autenticação a partir da variável de ambiente."""
    if not API_FOOTBALL_KEY:
        raise HTTPException(
            status_code=500,
            detail=(
                "API_FOOTBALL_KEY não configurada. Defina a variável de ambiente "
                "antes de iniciar o servidor — veja o arquivo .env."
            ),
        )
    return {"x-apisports-key": API_FOOTBALL_KEY}


async def call_api_football(path: str, params: Optional[dict] = None) -> dict:
    """Faz uma chamada GET autenticada para a API-Football e devolve o JSON já validado."""
    url = f"{API_FOOTBALL_BASE_URL}{path}"
    async with httpx.AsyncClient(timeout=15.0) as client:
        try:
            resp = await client.get(url, headers=get_headers(), params=params or {})
        except httpx.RequestError as exc:
            raise HTTPException(
                status_code=502, detail=f"Falha ao contatar a API-Football: {exc}"
            ) from exc

    if resp.status_code != 200:
        raise HTTPException(
            status_code=resp.status_code,
            detail=f"A API-Football retornou um erro: {resp.text}",
        )

    data = resp.json()
    if data.get("errors"):
        raise HTTPException(
            status_code=502, detail=f"Erro retornado pela API-Football: {data['errors']}"
        )

    return data


@app.get("/api/saude")
async def saude():
    """Rota simples para checar se a API está de pé (usada por monitoramento/uptime)."""
    return {"status": "ok", "servico": "Green Score IA - API"}


@app.get("/jogos/hoje")
async def jogos_hoje(liga: Optional[int] = None, temporada: Optional[int] = None):
    """
    Lista os jogos do dia de hoje.

    Parâmetros opcionais (query string):
      - liga: id da liga na API-Football (ex.: 71 para o Brasileirão Série A)
      - temporada: ano da temporada (ex.: 2026)
    """
    params = {"date": date.today().isoformat()}
    if liga is not None:
        params["league"] = liga
    if temporada is not None:
        params["season"] = temporada

    data = await call_api_football("/fixtures", params)
    return {"total": data.get("results", 0), "jogos": data.get("response", [])}


@app.get("/jogos/ao-vivo")
async def jogos_ao_vivo(liga: Optional[int] = None):
    """Lista os jogos que estão acontecendo agora. Use `liga` para filtrar por uma liga específica."""
    params = {"live": "all"}
    if liga is not None:
        params["league"] = liga

    data = await call_api_football("/fixtures", params)
    return {"total": data.get("results", 0), "jogos": data.get("response", [])}


@app.get("/jogo/{fixture_id}/estatisticas")
async def estatisticas_do_jogo(fixture_id: int):
    """Estatísticas do jogo: posse de bola, finalizações, escanteios, cartões, etc."""
    data = await call_api_football("/fixtures/statistics", {"fixture": fixture_id})
    if not data.get("response"):
        raise HTTPException(status_code=404, detail="Nenhuma estatística encontrada para esse jogo.")
    return {"fixture_id": fixture_id, "estatisticas": data["response"]}


@app.get("/jogo/{fixture_id}/eventos")
async def eventos_do_jogo(fixture_id: int):
    """Linha do tempo do jogo: gols, cartões, substituições, VAR, etc."""
    data = await call_api_football("/fixtures/events", {"fixture": fixture_id})
    return {"fixture_id": fixture_id, "eventos": data.get("response", [])}


async def obter_fixture(fixture_id: int) -> dict:
    """Busca os dados básicos de um jogo (times, liga, temporada) pelo id."""
    data = await call_api_football("/fixtures", {"id": fixture_id})
    if not data.get("response"):
        raise HTTPException(status_code=404, detail="Jogo não encontrado.")
    return data["response"][0]


async def obter_estatisticas_time(team_id: int, league_id: int, season: int) -> dict:
    """Busca as estatísticas da temporada de um time (médias de gols em casa/fora, etc.)."""
    data = await call_api_football(
        "/teams/statistics", {"team": team_id, "league": league_id, "season": season}
    )
    if not data.get("response"):
        raise HTTPException(
            status_code=404, detail=f"Sem estatísticas de temporada para o time {team_id}."
        )
    return data["response"]


async def obter_media_escanteios(team_id: int, ultimos_jogos: int = 5) -> float:
    """
    Calcula a média real de escanteios do time, olhando as estatísticas dos seus
    últimos jogos (a API-Football não traz essa média pronta no /teams/statistics).
    """
    data = await call_api_football("/fixtures", {"team": team_id, "last": ultimos_jogos})
    fixtures = data.get("response", [])
    valores = []
    for f in fixtures:
        fixture_id_anterior = f["fixture"]["id"]
        stats_data = await call_api_football(
            "/fixtures/statistics", {"fixture": fixture_id_anterior}
        )
        for time_stats in stats_data.get("response", []):
            if time_stats["team"]["id"] == team_id:
                for item in time_stats.get("statistics", []):
                    if item["type"] == "Corner Kicks" and item["value"] is not None:
                        valores.append(float(item["value"]))
    return mean(valores) if valores else 0.0


@app.get("/jogo/{fixture_id}/previsao")
async def previsao_do_jogo(fixture_id: int):
    """
    Calcula probabilidades reais (resultado, gols, BTTS, escanteios) com o motor
    matemático do analysis.py, a partir de estatísticas reais da temporada dos
    dois times na API-Football — sem inventar números.

    Se a API-Football não tiver médias de gols suficientes para algum dos times,
    a rota avisa com um erro em vez de estimar um valor no lugar.
    """
    fixture = await obter_fixture(fixture_id)
    liga = fixture["league"]["id"]
    temporada = fixture["league"]["season"]
    time_casa = fixture["teams"]["home"]
    time_fora = fixture["teams"]["away"]

    stats_casa = await obter_estatisticas_time(time_casa["id"], liga, temporada)
    stats_fora = await obter_estatisticas_time(time_fora["id"], liga, temporada)

    try:
        gols_casa_marcados = float(stats_casa["goals"]["for"]["average"]["home"])
        gols_casa_sofridos = float(stats_casa["goals"]["against"]["average"]["home"])
        gols_fora_marcados = float(stats_fora["goals"]["for"]["average"]["away"])
        gols_fora_sofridos = float(stats_fora["goals"]["against"]["average"]["away"])
    except (KeyError, TypeError, ValueError) as exc:
        raise HTTPException(
            status_code=502,
            detail=(
                "A API-Football não retornou médias de gols suficientes para "
                "calcular a previsão deste jogo."
            ),
        ) from exc

    media_escanteios_casa = await obter_media_escanteios(time_casa["id"])
    media_escanteios_fora = await obter_media_escanteios(time_fora["id"])

    previsao = analisar_partida(
        gols_marcados_casa=gols_casa_marcados,
        gols_sofridos_casa=gols_casa_sofridos,
        gols_marcados_fora=gols_fora_marcados,
        gols_sofridos_fora=gols_fora_sofridos,
        escanteios_casa=media_escanteios_casa,
        escanteios_fora=media_escanteios_fora,
    )

    # A IA só entra aqui para EXPLICAR os números acima em texto — ela não recalcula
    # nem recebe nenhum dado além do que o analysis.py já produziu. Se a chave da
    # Anthropic não estiver configurada, explicacao_ia vem como null e os números
    # continuam disponíveis normalmente.
    explicacao = explicar_previsao(time_casa["name"], time_fora["name"], previsao)

    return {
        "fixture_id": fixture_id,
        "mandante": time_casa["name"],
        "visitante": time_fora["name"],
        "previsao": previsao,
        "explicacao_ia": explicacao,
        "fonte": "Calculado pelo analysis.py (modelo de Poisson) a partir de médias reais da API-Football.",
    }


# ===================== SITE (front-end) =====================
# Serve o site (pasta static/, com o index.html do Green Score IA) no mesmo
# domínio da API. Como fica tudo na mesma origem, o front-end consegue chamar
# /jogos/hoje, /jogos/ao-vivo etc. sem nenhuma configuração extra de CORS.
# Precisa vir DEPOIS de todas as rotas de API acima, senão elas ficam encobertas.
app.mount("/", StaticFiles(directory="static", html=True), name="static")
